# Upper-case extension
1. counts as text